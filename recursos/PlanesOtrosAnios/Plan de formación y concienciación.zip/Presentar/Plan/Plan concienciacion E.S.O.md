
---

# Plan de Concienciación y Formación en Ciberseguridad para Alumnos de 1º a 4º de E.S.O.

## 1. Introducción y Justificación

**Contexto:** 
Todas las personas, de cualquier condición y en cualquier ámbito, se encuentran expuestas a multitud de riesgos digitales, pero, como es nuestro caso, los jóvenes en edad escolar se encuentran expuestos de manera mas significativa.
Nos referimos a riesgos que pueden ir desde el ciberacoso (ciberbullying), un uso indebido o inadecuado de los dispositivos y redes sociales, hasta estafas y chantajes. Es por este motivo que la formación en ciberseguridad no se centra unicamente en la protección de los datos, dispositivos y demás activos digitales, sino que va mas allá tratando de conseguir que los estudiantes se formen para llegar a ser usuarios críticos y responsables, capaces de discernir y tomar decisiones acertadas, para conseguir tener un optimo bienestar digital.
 
**Justificación:**  
Este plan busca, de algún modo, conseguir que el “eslabón” mas débil en la cadena de seguridad, el factor humano, sea reforzado de modo que no se conviertan en un riesgo para la seguridad general. Los alumnos, como hemos mencionado antes, deben, como usuarios consumidores a diario de tecnología, tener las herramientas y el conocimiento para desarrollar buenas practicas de modo que les permitan prevenir incidentes y llegado el caso de una situación real de riesgo, saber proceder o actuar de manera correcta y adecuada.

## 2. Objetivos del Plan

- **Objetivos Generales:**
  - Fomentar entre los alumnos un conocimiento y una cultura de ciberseguridad.
  - Alentar a los alumnos a desarrollar buenas practicas en el uso de la tecnología
  - Reducir al máximo los comportamientos que puedan poner en riesgo su seguridad y bienestar.
  
- **Objetivos Específicos:**
  - Sensibilizar sobre los riesgos y consecuencias del ciberbullying, phishing, uso indebido de contraseñas y otros ataques digitales.
  - Promover el uso responsable de dispositivos móviles, redes sociales y otros activos digitales.
  - Desarrollar habilidades prácticas para identificar y gestionar amenazas en el todos los ámbitos digitales.
  - Animar a la participación de forma activa en actividades de formación mediante metodologías lúdicas y dinámicas, adaptadas a cada edad.

## 3. Alcance del Plan

- **Público objetivo:**  
  Los alumnos de los cursos comprendidos entre 1º a 4º de E.S.O.  
- **Áreas de actuación:**  
  - Uso de dispositivos móviles y ordenadores.
  - Navegación en internet y redes sociales.
  - Prevención y actuación ante el ciberacoso.
- **Limitaciones:**
  Se tratará siempre de evitar el uso de contenido y vocabulario técnico que pudiera ser excesivamente complejo, adaptando el lenguaje y la metodología usada, a la madurez del grupo de alumnos que reciben la formación.

## 4. Diagnóstico Inicial

### 4.1. Evaluación de Necesidades
- **Encuestas y Cuestionarios Iniciales:**  
  Se aplicarán formularios adaptados al lenguaje de los estudiantes con preguntas como:
  - ¿Conoces las principales amenazas cibernéticas?
  - ¿Sabes qué es el phishing y cómo protegerte de él?
  - ¿Utilizas contraseñas seguras y únicas para cada cuenta?
  - ¿Con qué frecuencia cambias tus contraseñas?
  - ¿Crees que eres capaz de identificar un correo o mensaje fraudulento?
- **Análisis de Conocimientos Previos:**  
  Revisión de incidentes previos en el centro educativo y análisis de estadísticas de uso de dispositivos y redes.

### 4.2. Identificación de Riesgos
- **Principales Amenazas Detectadas:**  
  - Ciberbullying.
  - Uso indebido o inadecuado de contraseñas y datos personales.
  - Descargas no autorizadas o ilegitimas y malware.
  - Riesgos y consecuencias derivadas de un uso excesivo o inadecuado del móvil y otros dispositivos así como de las redes sociales.

### 4.3. Segmentación de Alumnos
- **Por Curso y Edad:**  
  - 1º y 2º de E.S.O.: Contenido enfocado en aspectos básicos de ciberseguridad, uso seguro de dispositivos y detección de riesgos comunes, así como la protección de datos personales y prevención del ciberacoso. Todo este contenido será adaptado a la madurez de los alumnos.
  - 3º y 4º de E.S.O.: Contenido enfocado en aspectos básicos y de nivel algo mas avanzado, de ciberseguridad, uso seguro de dispositivos y detección de riesgos comunes, así como la protección de datos personales y prevención del ciberacoso. Se usará un vocabulario algo mas técnico y se profundizará algo mas en materias concretas de ciberseguridad, adaptándolo siempre a la madurez de los alumnos.

## 5. Diseño del Plan de Formación y Concienciación

### 5.1. Definición de Contenidos Formativos
- **Contenidos Básicos:**
  - Introducción a la ciberseguridad: Algunos conceptos y definiciones, con ejemplos.
  - Uso y creación segura de contraseñas y políticas de “mesa limpia” en los dispositivos.
  - Muestra de pautas a seguir para conseguir un reconocimiento de mensajes y correos sospechosos y/o fraudulentos.
- **Contenidos Específicos para el Entorno Escolar:**
  - Como prevenir y actuar ante el ciberacoso.
  - Uso responsable y ético de las redes sociales.
  - Como gestionar de manera correcta la identidad digital y privacidad, haciendo hincapié en la importancia de asegurar el correo electrónico.
  - Dar a conocer los posibles riesgos y buenas prácticas en el uso de dispositivos móviles.

### 5.2. Asociación de Contenidos y Materiales
Se propondrá una tabla de asignación por curso/grupo:

| Grupo (Curso)        | Temas Principales                                  | Materiales y Herramientas                           |
|----------------------|----------------------------------------------------|-----------------------------------------------------|
| 1º y 2º de E.S.O.    | Conceptos básicos, debate sobre el uso seguro de contraseñas y como crear contraseñas seguras, Muestra de pautas para identificar correos/sitios fraudulentos      | Ejemplos en vivo, presentaciones, participación activa y pequeños juegos en grupo   |
| 3º y 4º de E.S.O.    | Conceptos básicos, debate sobre el uso seguro de contraseñas y como crear contraseñas seguras, Muestra de pautas para identificar correos/sitios fraudulentos        | Ejemplos en vivo, presentaciones, participación activa y pequeños juegos en grupo     |

### 5.3. Metodologías Formativas
- **Enfoque Lúdico y Participativo:**  
  Uso de ejemplos y pequeños debates para fomentar la participación activa, demostraciones en vivo y simulaciones que permitan a los alumnos descubrir por si mismos sitios fraudulentos, así como la forma adecuada de crear una contraseña segura.
- **Modalidades:**  
  - Sesión presencial en el centro.
  - Debates participativos.
  - Demostraciones.
  - Reparto de panfletos informativos.
- **Recursos Digitales y Multimedia:**
  Presentaciones llamativas, demostraciones en vivo, ejemplos claros y con impacto, que consigan concienciar a los alumnos y afianzar los conocimientos adquiridos.

## 6. Ejecución del Plan

### 6.1. Cronograma de Actividades
Se ha establecido un cronograma a corto plazo, el cual incluye lo siguiente: 

| Mes      | Actividad                                          | Objetivo Específico                                       |
|----------|----------------------------------------------------|-----------------------------------------------------------|
| ENERO | **Evaluación inicial y diagnóstico:** Aplicación de cuestionarios y encuestas. | Conocer el nivel de conocimientos del alumnado y sus actitudes actuales.   |
| 11 y 12 FEBRERO  | **Charlas participativas y activas:** “Cuidándonos en el mundo digital”  | Introducir conceptos básicos y educar en la prevención e identificación de riesgos.     |
| MARZO    | **Revisión y feedback:** Encuestas de satisfacción y autoevaluación. | Evaluar la efectividad de las actividades realizadas y detectar posibles áreas de mejora. |

### 6.2. Distribución y Uso de Materiales
- **Canales de Distribución:**  
  - Medios técnicos del centro, como proyectores, ordenadores, etc.
  - Material impreso en aulas (posters, folletos) para refuerzo visual.
  - Uso de correos electrónicos corporativos y redes internas del centro para notificaciones.
- **Responsables de la Distribución:**  
  Coordinadores TIC, profesores responsables de cada curso y personal del departamento de orientación.

### 6.3. Roles y Responsabilidades
- **Coordinador del Plan:**  
  Responsable de la planificación general, seguimiento y coordinación entre los distintos departamentos (TIC, Orientación y Dirección).
- **Profesores y Tutores:**  
  Facilitar recursos y recogida y envío del feedback.
- **Responsable TIC del centro:**  
  Soporte técnico y preparación de medios digitales.
- **Alumnos:**  
  Participación activa y cumplimiento de las actividades formativas.

## 7. Evaluación del Plan

### 7.1. Indicadores de Evaluación
- **Participación y Asistencia:**  
  Medida del porcentaje de alumnos que han asistido a la sesión formativa.
- **Resultados en Evaluaciones y Simulaciones:**  
  Medición y baremación de la mejora en la capacidad de identificar riesgos.
- **Feedback Cualitativo:**  
  Encuestas de satisfacción y autoevaluaciones de los alumnos.
- **Reducción de Incidentes:**  
  Comparación de actitudes detectadas antes y después de la implementación del plan.

### 7.2. Herramientas de Evaluación
- **Encuestas y Cuestionarios:**  
  Aplicados al inicio y al final la formación.
- **Reuniones de Retroalimentación:**  
  Sesiones periódicas con profesores y coordinadores para analizar resultados y ajustar o establecer estrategias.

## 8. Mejora Continua y Actualización

- **Revisión Periódica:**  
  Actualización del contenido y metodología al finalizar cada curso escolar, teniendo en cuenta las nuevas amenazas existentes y el feedback obtenido de los alumnos.
- **Integración de Sugerencias:**  
  Incorporación de ideas surgidas en las encuestas y reuniones de retroalimentación.
- **Plan de Contingencia:**  
  Elaboración de protocolos para responder a nuevos riesgos emergentes (por ejemplo, amenazas vinculadas a nuevas tecnologías o tendencias en redes sociales).

---

## Conclusión
Con el presente plan, se trata de concienciar y formas a los alumnos estudiantes de 1º a 4º de la E.S.O. de las herramientas y buenas prácticas necesarias para navegar y/o usar de forma segura y responsable el entorno digital, así como dotar a los alumnos de un pensamiento critico y formado para poder identificar, prevenir y mitigar posibles riesgos de seguridad. Implantando un sistema de seguimiento y evaluación constante, se trata de consolidar una férrea cultura de ciberseguridad, que pueda evitar que los alumnos se conviertan en el “eslabón débil” en la cadena de seguridad.
Este plan puede modificarse y/o adaptarse a las necesidades del centro y los alumnos del mismo, tras la obtención de los primeros datos en la encuesta previa o bien, en los datos obtenidos en la encuesta de feedback, así como en las conclusiones obtenidas durante las reuniones de retroalimentación.

---
